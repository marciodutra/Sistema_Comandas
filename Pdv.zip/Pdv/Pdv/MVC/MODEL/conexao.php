<?php
	
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "pdv";


	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>